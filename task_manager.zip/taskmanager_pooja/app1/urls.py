from django.urls import path

from . import views

urlpatterns = [

    path(
        "",
        views.dashboard,
        name="dashboard"
    ),

    path(
        "create/",
        views.create_task,
        name="create_task"
    ),

    path(
        "edit/<int:pk>/",
        views.edit_task,
        name="edit_task"
    ),

    path(
        "delete/<int:pk>/",
        views.delete_task,
        name="delete_task"
    ),

    path(
        "trash/",
        views.trash,
        name="trash"
    ),

    path(
        "restore/<int:pk>/",
        views.restore_task,
        name="restore_task"
    ),

    path(
        "permanent-delete/<int:pk>/",
        views.permanent_delete,
        name="permanent_delete"
    ),
]