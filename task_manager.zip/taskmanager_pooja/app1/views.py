from django.shortcuts import render
from django.shortcuts import redirect
from django.shortcuts import get_object_or_404

from .models import Task
from .forms import TaskForm


def dashboard(request):

    tasks = Task.objects.filter(
        is_deleted=False
    )

    context = {
        "todo_tasks":
            tasks.filter(status="todo"),

        "progress_tasks":
            tasks.filter(status="progress"),

        "completed_tasks":
            tasks.filter(status="completed"),
    }

    return render(
        request,
        "dashboard.html",
        context
    )


def create_task(request):

    if request.method == "POST":

        form = TaskForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect("dashboard")

    else:
        form = TaskForm()

    return render(
        request,
        "task_form.html",
        {"form": form}
    )


def edit_task(request, pk):

    task = get_object_or_404(Task, pk=pk)

    if request.method == "POST":

        form = TaskForm(
            request.POST,
            instance=task
        )

        if form.is_valid():
            form.save()
            return redirect("dashboard")

    else:
        form = TaskForm(instance=task)

    return render(
        request,
        "task_form.html",
        {"form": form}
    )


def delete_task(request, pk):

    task = get_object_or_404(Task, pk=pk)

    task.is_deleted = True
    task.save()

    return redirect("dashboard")


def trash(request):

    tasks = Task.objects.filter(
        is_deleted=True
    )

    return render(
        request,
        "trash.html",
        {"tasks": tasks}
    )


def restore_task(request, pk):

    task = get_object_or_404(Task, pk=pk)

    task.is_deleted = False
    task.save()

    return redirect("trash")


def permanent_delete(request, pk):

    task = get_object_or_404(Task, pk=pk)

    task.delete()

    return redirect("trash")